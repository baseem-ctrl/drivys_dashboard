import { useEffect, useState } from 'react';
import {
  Card,
  Typography,
  Avatar,
  Box,
  Switch,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  CircularProgress,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import { useAuthContext } from 'src/auth/hooks';
import { useGetGenderEnum } from 'src/api/users';
import { paths } from 'src/routes/paths';
import { useRouter } from 'src/routes/hooks';
import { useTranslation } from 'react-i18next';

// You'll need to create this API hook
// import { useGetRecentBookings } from 'src/api/bookings';

const OverviewAssistant = () => {
  const { user } = useAuthContext();
  const router = useRouter();
  const { t, i18n } = useTranslation();
  const { genderData, genderLoading } = useGetGenderEnum();

  // Uncomment when you have the API hook
  // const { bookings, bookingsLoading } = useGetRecentBookings();

  // Temporary dummy data - remove when API is ready
  const bookings = [
    { id: 'BK123', studentName: 'Cameron Williamson', trainerName: 'Albert Flores', bookingStatus: 'Completed', paymentStatus: 'Paid' },
    { id: 'BK124', studentName: 'Ronald Richards', trainerName: 'Devon Lane', bookingStatus: 'Pending', paymentStatus: 'Not Paid' },
    { id: 'BK125', studentName: 'Cody Fisher', trainerName: 'Savannah Nguyen', bookingStatus: 'Completed', paymentStatus: 'Paid' },
    { id: 'BK126', studentName: 'Esther Howard', trainerName: 'Kristin Watson', bookingStatus: 'Pending', paymentStatus: 'Not Paid' },
    { id: 'BK127', studentName: 'Annette Black', trainerName: 'Leslie Alexander', bookingStatus: 'Completed', paymentStatus: 'Paid' },
    { id: 'BK128', studentName: 'Brooklyn Simmons', trainerName: 'Dianne Russell', bookingStatus: 'Pending', paymentStatus: 'Not Paid' },
    { id: 'BK129', studentName: 'Marvin McKinney', trainerName: 'Eleanor Pena', bookingStatus: 'Completed', paymentStatus: 'Paid' },
    { id: 'BK130', studentName: 'Jenny Wilson', trainerName: 'Jane Cooper', bookingStatus: 'Pending', paymentStatus: 'Paid' },
  ];
  const bookingsLoading = false;

  const [formData, setFormData] = useState({
    name: user?.user?.name || '',
    email: user?.user?.email || '',
    phone: user?.user?.phone || '',
    dob: user?.user?.dob || '',
    status: user?.user?.is_active || '',
    gender: '',
    profileUrl: user?.user?.photo_url || '',
  });

  useEffect(() => {
    if (genderData && genderData?.length && user?.user?.gender) {
      const matchedGender = genderData.find(
        (option) => option.name.toLowerCase() === user.user.gender.toLowerCase()
      )?.value;

      if (matchedGender) {
        setFormData((prev) => ({ ...prev, gender: matchedGender }));
      }
    }
  }, [genderData, user?.user?.gender]);

  const [isActive, setIsActive] = useState(user?.user?.is_active || false);

  const handleToggle = (event) => {
    setIsActive(event.target.checked);
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleClickSave = () => {
    router.push(paths.dashboard.assistant.edit);
  };

  const getStatusColor = (status) => {
    if (status === 'Completed') return 'success';
    if (status === 'Pending') return 'warning';
    return 'default';
  };

  return (
    <Box sx={{  p: 5,   borderRadius: 3, bgcolor: '#f5f5f5', minHeight: '100vh' }}>
      <Typography variant="h4" fontWeight={700} mb={3}>
        {t('profile')}
      </Typography>

      <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
        {/* Profile Card */}
        <Card
          elevation={4}
          sx={{
            width: { xs: '100%', md: 540 },
            borderRadius: 3,
            overflow: 'hidden',
            bgcolor: 'white',
          }}
        >
          {/* Header with gradient background */}
          <Box
            sx={{
              height: 180,
              background: 'linear-gradient(135deg, #1a1a1a 0%, #2d5016 50%, #1a1a1a 100%)',
              position: 'relative',
            }}
          >
            <Avatar
              src={user?.user?.photo_url || '/static/images/avatar_placeholder.png'}
              sx={{
                width: 160,
                height: 160,
                border: '6px solid white',
                position: 'absolute',
                bottom: -60,
                left: '50%',
                transform: 'translateX(-50%)',
                boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
              }}
            />
          </Box>

          {/* Profile Info */}
          <Box sx={{ pt: 9, pb: 4, px: 4 }}>
            {/* Name, Role, Gender */}
            <Box sx={{ display: 'flex', gap: 2, mb: 4, textAlign: 'center' }}>
              <Box sx={{ flex: 1 }}>
                <Typography
                  sx={{
                    color: '#ff8c42',
                    fontSize: '11px',
                    fontWeight: 600,
                    letterSpacing: 0.5,
                    mb: 0.5,
                  }}
                >
                  {t('full_name').toUpperCase()}
                </Typography>
                <Typography sx={{ fontSize: '16px', fontWeight: 600 }}>
                  {i18n.language === 'en'
                    ? user?.user?.name
                    : user?.user?.name_ar || t('n/a')}
                </Typography>
              </Box>
              <Box sx={{ flex: 1 }}>
                <Typography
                  sx={{
                    color: '#ff8c42',
                    fontSize: '11px',
                    fontWeight: 600,
                    letterSpacing: 0.5,
                    mb: 0.5,
                  }}
                >
                  {t('role').toUpperCase()}
                </Typography>
                <Typography sx={{ fontSize: '16px', fontWeight: 600 }}>
                  {user?.user?.user_type || t('n/a')}
                </Typography>
              </Box>
              <Box sx={{ flex: 1 }}>
                <Typography
                  sx={{
                    color: '#ff8c42',
                    fontSize: '11px',
                    fontWeight: 600,
                    letterSpacing: 0.5,
                    mb: 0.5,
                  }}
                >
                  {t('gender').toUpperCase()}
                </Typography>
                <Typography sx={{ fontSize: '16px', fontWeight: 600 }}>
                  {user?.user?.gender || t('n/a')}
                </Typography>
              </Box>
            </Box>

            {/* DOB, Phone, Status */}
            <Box sx={{ display: 'flex', gap: 2, mb: 3, textAlign: 'center' }}>
              <Box sx={{ flex: 1 }}>
                <Typography
                  sx={{
                    color: '#ff8c42',
                    fontSize: '11px',
                    fontWeight: 600,
                    letterSpacing: 0.5,
                    mb: 0.5,
                  }}
                >
                  {t('dob').toUpperCase()}
                </Typography>
                <Typography sx={{ fontSize: '16px', fontWeight: 600 }}>
                  {user?.user?.dob || t('n/a')}
                </Typography>
              </Box>
              <Box sx={{ flex: 1 }}>
                <Typography
                  sx={{
                    color: '#ff8c42',
                    fontSize: '11px',
                    fontWeight: 600,
                    letterSpacing: 0.5,
                    mb: 0.5,
                  }}
                >
                  {t('Phone').toUpperCase()}
                </Typography>
                <Typography sx={{ fontSize: '16px', fontWeight: 600 }}>
                  +971 {user?.user?.phone || t('n/a')}
                </Typography>
              </Box>
              <Box sx={{ flex: 1 }}>
                <Typography
                  sx={{
                    color: '#ff8c42',
                    fontSize: '11px',
                    fontWeight: 600,
                    letterSpacing: 0.5,
                    mb: 0.5,
                  }}
                >
                  {t('status').toUpperCase()}
                </Typography>
                <Box sx={{ flex: 1 }}>

                  <Typography
                    sx={{
                      fontSize: '13px',
                      fontWeight: 500,
                      color: user?.user?.is_active ? 'success.main' : 'error.main',
                    }}
                  >
                    {user?.user?.is_active ? 'Active' : 'Inactive'}
                  </Typography>
                </Box>



              </Box>
            </Box>

            {/* Edit Button */}
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
              <Button
                variant="outlined"
                startIcon={<EditIcon />}
                onClick={handleClickSave}
                sx={{
                  color: '#ff8c42',
                  borderColor: '#ff8c42',
                  px: 4,
                  py: 1,
                  borderRadius: 2,
                  textTransform: 'none',
                  fontSize: '14px',
                  fontWeight: 600,
                  '&:hover': {
                    borderColor: '#ff8c42',
                    bgcolor: 'rgba(255, 140, 66, 0.04)',
                  },
                }}
              >
                {t('edit_profile')}
              </Button>
            </Box>
          </Box>
        </Card>

        {/* Recent Bookings Table */}
        <Card
          elevation={4}
          sx={{
            flex: 1,
            minWidth: { xs: '100%', md: 600 },
            borderRadius: 3,
            bgcolor: 'white',
            p: 3,
          }}
        >
          <Typography variant="h6" fontWeight={600} mb={2}>
            {t('recent_bookings')}
          </Typography>

          {bookingsLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
              <CircularProgress />
            </Box>
          ) : (
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow sx={{ bgcolor: '#f5f5f5' }}>
                    <TableCell sx={{ fontWeight: 600, fontSize: '13px' }}>
                      {t('id')}
                    </TableCell>
                    <TableCell sx={{ fontWeight: 600, fontSize: '13px' }}>
                      {t('student_name')}
                    </TableCell>
                    <TableCell sx={{ fontWeight: 600, fontSize: '13px' }}>
                      {t('trainer_name')}
                    </TableCell>
                    <TableCell sx={{ fontWeight: 600, fontSize: '13px' }}>
                      {t('booking_status')}
                    </TableCell>
                    <TableCell sx={{ fontWeight: 600, fontSize: '13px' }}>
                      {t('payment_status')}
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {bookings && bookings.length > 0 ? (
                    bookings.map((booking) => (
                      <TableRow key={booking.id} hover>
                        <TableCell sx={{ fontSize: '13px' }}>{booking.id}</TableCell>
                        <TableCell sx={{ fontSize: '13px' }}>
                          {booking.studentName}
                        </TableCell>
                        <TableCell sx={{ fontSize: '13px' }}>
                          {booking.trainerName}
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={booking.bookingStatus}
                            color={getStatusColor(booking.bookingStatus)}
                            size="small"
                            sx={{ fontSize: '12px', fontWeight: 500 }}
                          />
                        </TableCell>
                        <TableCell>
                          <Typography
                            sx={{
                              color:
                                booking.paymentStatus === 'Paid' ? '#4caf50' : '#f44336',
                              fontSize: '13px',
                              fontWeight: 500,
                            }}
                          >
                            {booking.paymentStatus}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={5} align="center">
                        <Typography variant="body2" color="text.secondary">
                          {t('no_bookings_found')}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Card>
      </Box>
    </Box>
  );
};

export default OverviewAssistant;

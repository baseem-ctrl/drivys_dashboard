import React from 'react';
import {
  Avatar,
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  Stack,
  Button,
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';

type Trainer = {
  name: string;
  email: string;
  phone: string;
  photo: string;
  dob: string;
  is_active: boolean;
  gender: string;
  vehicle_number?: string;
  user?: {
    name?: string;
    name_ar?: string;
    email?: string;
    photo_url?: string;
    is_active?: boolean;
    languages?: Array<{
      dialect?: {
        language_name?: string;
      };
    }>;
    user_preference?: {
      gear?: string;
      vehicle_type?: {
        category_translations?: Array<{
          locale?: string;
          name?: string;
        }>;
      };
    };
  };
};

type TrainerProfileCardProps = {
  row: Trainer;
};

const TrainerProfileCard: React.FC<TrainerProfileCardProps> = ({ row }) => {
  const { i18n, t } = useTranslation();

  // Get gear type from user preference
  const gearType = row?.user?.user_preference?.gear || 'Unknown';
  const isManual = gearType.toLowerCase() === 'manual';
  const isAutomatic = gearType.toLowerCase() === 'automatic';

  // Get vehicle number
  const vehicleNumber = row?.vehicle_number || 'N/A';

  return (
    <Card
      sx={{
        width: '100%',
        maxWidth: 650,
        borderRadius: 2,
        boxShadow: 2,
        overflow: 'hidden',
        backgroundColor: '#fff',
        position: 'relative',
        background: 'linear-gradient(to bottom, #ffffff 0%, #ffffff 60%, #f5f5f5 100%)',
      }}
    >
      <CardContent sx={{ p: 0, '&:last-child': { pb: 0 } }}>
        <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2, p: 2, position: 'relative' }}>
          {/* Avatar */}
          <Avatar
            src={row?.user?.photo_url}
            alt={row?.user?.name}
            sx={{
              width: 105,
              height: 105,
              borderRadius: 2,
              flexShrink: 0,
            }}
          />

          {/* Content */}
          <Box sx={{ flex: 1, minWidth: 0, pt: 0.5 }}>
            {/* Name and Email */}
            <Typography
              sx={{ fontSize: '15px', fontWeight: 600, color: '#000', mb: 0.3 }}
              noWrap
            >
              {i18n.language === 'ar' ? row?.user?.name_ar || row?.user?.name || t('n/a') : row?.user?.name || t('n/a')}
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 1.5 }}>
              <Box
                component="span"
                sx={{
                  width: 14,
                  height: 14,
                  display: 'inline-flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" stroke="#9e9e9e" strokeWidth="2" fill="none"/>
                  <path d="M22 6l-10 7L2 6" stroke="#9e9e9e" strokeWidth="2" fill="none"/>
                </svg>
              </Box>
              <Typography
                sx={{ fontSize: '12px', color: '#757575' }}
                noWrap
              >
                {row?.user?.email || t('n/a')}
              </Typography>
            </Box>

            {/* Buttons Row */}
            <Stack direction="row" spacing={1} sx={{ mb: 1.5 }} flexWrap="wrap">
              {/* Show Manual button only if gear is Manual */}
              {isManual && (
                <Button
                  size="small"
                  variant="contained"
                  startIcon={<Box component="span" sx={{ fontSize: '16px', fontWeight: 'bold' }}>≡</Box>}
                  sx={{
                    backgroundColor: '#1565c0',
                    fontSize: '12px',
                    minWidth: 'auto',
                    px: 1.5,
                    py: 0.5,
                    textTransform: 'none',
                    fontWeight: 600,
                    height: 28,
                    color: '#ffffff',
                    '&:hover': { backgroundColor: '#0d47a1' },
                    '& .MuiButton-startIcon': { marginRight: '4px', color: '#ffffff' }
                  }}
                >
                  {t('manual')}
                </Button>
              )}

              {/* Show Automatic button only if gear is Automatic */}
              {isAutomatic && (
                <Button
                  size="small"
                  variant="contained"
                  startIcon={<Box component="span" sx={{ fontSize: '14px' }}>⚙</Box>}
                  sx={{
                    backgroundColor: '#e65100',
                    fontSize: '12px',
                    minWidth: 'auto',
                    px: 1.5,
                    py: 0.5,
                    textTransform: 'none',
                    fontWeight: 600,
                    height: 28,
                    color: '#ffffff',
                    '&:hover': { backgroundColor: '#bf360c' },
                    '& .MuiButton-startIcon': { marginRight: '4px', color: '#ffffff' }
                  }}
                >
                  {t('automatic')}
                </Button>
              )}

              {/* Show gear type if Unknown */}
              {!isManual && !isAutomatic && gearType !== 'Unknown' && (
                <Button
                  size="small"
                  variant="contained"
                  sx={{
                    backgroundColor: '#424242',
                    fontSize: '12px',
                    minWidth: 'auto',
                    px: 1.5,
                    py: 0.5,
                    textTransform: 'none',
                    fontWeight: 600,
                    height: 28,
                    color: '#ffffff',
                    '&:hover': { backgroundColor: '#212121' },
                  }}
                >
                  {gearType}
                </Button>
              )}

              {/* Vehicle Number Chip */}
              <Chip
                label={vehicleNumber}
                size="small"
                variant="outlined"
                sx={{
                  fontSize: '12px',
                  height: 28,
                  borderColor: '#757575',
                  borderWidth: 1.5,
                  fontWeight: 600,
                  color: '#212121',
                  backgroundColor: '#f5f5f5',
                }}
              />
            </Stack>

            {/* Vehicle Category */}
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.8 }}>
              <Typography sx={{ fontSize: '12px', color: '#424242', minWidth: 110, fontWeight: 500 }}>
                {t('vehicle_category')}:
              </Typography>
              <Chip
                icon={<DirectionsCarIcon sx={{ fontSize: 14 }} />}
                label={
                  row?.user?.user_preference?.vehicle_type?.category_translations?.find(
                    (t) => t?.locale?.toLowerCase() === i18n.language.toLowerCase()
                  )?.name ||
                  row?.user?.user_preference?.vehicle_type?.category_translations?.[0]?.name ||
                  t('car')
                }
                size="small"
                sx={{
                  backgroundColor: '#0d47a1',
                  color: 'white',
                  fontSize: '11px',
                  height: 22,
                  fontWeight: 600,
                  '& .MuiChip-icon': { color: 'white', marginLeft: '6px' }
                }}
              />
            </Box>

            {/* Languages */}
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Typography sx={{ fontSize: '12px', color: '#424242', minWidth: 110, fontWeight: 500 }}>
                {t('language')}:
              </Typography>
              <Typography sx={{ fontSize: '12px', color: '#212121', fontWeight: 500 }}>
                {row?.user?.languages?.length > 0
                  ? row.user.languages
                      .map((lang: any) => lang.dialect?.language_name)
                      .filter(Boolean)
                      .join(', ')
                  : t('n/a')}
              </Typography>
            </Box>
          </Box>

          {/* Active Status Badge - Positioned at top right */}
          <Box sx={{ position: 'absolute', top: 16, right: 16 }}>
            <Chip
              label={row?.user?.is_active ? t('active') : t('inactive')}
              size="small"
              sx={{
                backgroundColor: row?.user?.is_active ? '#2e7d32' : '#c62828',
                color: 'white',
                fontWeight: 700,
                fontSize: '11px',
                height: 24,
              }}
            />
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
};

export default TrainerProfileCard;

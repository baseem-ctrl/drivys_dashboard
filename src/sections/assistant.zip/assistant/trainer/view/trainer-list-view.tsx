/* eslint-disable no-nested-ternary */
import React, { useCallback, useState } from 'react';
import isEqual from 'lodash/isEqual';
import {
  Grid,
  CircularProgress,
  Typography,
  Box,
  Stack,
  InputAdornment,
  IconButton,
  TextField,
  Card,
  Button,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import CloseIcon from '@mui/icons-material/Close';
import FilterListIcon from '@mui/icons-material/FilterList';
import { useGetTrainerList } from 'src/api/assistant';
import { TablePaginationCustom, useTable } from 'src/components/table';
import { paths } from 'src/routes/paths';
import { useSettingsContext } from 'src/components/settings';
import { useRouter } from 'src/routes/hooks';
import { useBoolean } from 'src/hooks/use-boolean';
import { IUserTableFilterValue } from 'src/types/city';
import HourglassEmptyIcon from '@mui/icons-material/HourglassEmpty';
import { useGetGearEnum } from 'src/api/users';
import { useTranslation } from 'react-i18next';
import TrainerProfileCard from '../trainer-profile-card';
import TrainerFilters from '../trainer-filter';

const defaultFilters: any = {
  city_id: '',
  vehicle_type_id: { label: '', value: '' },
  gear: '',
  vendor_id: { label: '', value: '' },
};

const TrainerListPage: React.FC = () => {
  const table = useTable({ defaultRowsPerPage: 10 });
  const settings = useSettingsContext();
  const router = useRouter();
  const openFilters = useBoolean();
  const [filters, setFilters] = useState(defaultFilters);
  const { gearData, gearLoading } = useGetGearEnum();
  const { t } = useTranslation();
  const [searchTermTrainer, setSearchTermTrainer] = useState('');

  const { trainers, trainerListLoading, trainerListError, totalTrainerPages } = useGetTrainerList({
    page: table.page,
    limit: 1000,
    ...(filters.vendor_id?.value ? { vendor_id: filters.vendor_id.value } : {}),
    ...(filters.vehicle_type_id?.value ? { vehicle_type_id: filters.vehicle_type_id.value } : {}),
    ...(filters.gear !== '' && gearData?.length
      ? { gear: gearData.find((g: any) => g.name === filters.gear)?.value }
      : {}),
    ...(filters.city_id ? { city_id: filters.city_id } : {}),
    search: searchTermTrainer,
  });

  const canReset = !isEqual(defaultFilters, filters);

  const handleResetFilters = useCallback(() => {
    setFilters(defaultFilters);
  }, []);

  const handleFilters = useCallback(
    (name: string, value: IUserTableFilterValue) => {
      table.onResetPage();
      setFilters((prevState) => ({
        ...prevState,
        [name]: value,
      }));
    },
    [table]
  );

  const handleClickTrainerDetails = (id) => {
    router.push(paths.dashboard.assistant.trainer.details(id));
  };

  const handleClearSearch = () => {
    setSearchTermTrainer('');
  };

  return (
    <Box sx={{ p: 5, bgcolor: '#fafafa', minHeight: '100vh', borderRadius: 3,}}>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" sx={{ fontWeight: 600, mb: 0.5 }}>
          {t('Trainers')}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {t('Home')} / <span style={{ color: '#ff6b35' }}>{t('Trainers')}</span>
        </Typography>
      </Box>

      {/* White Card Container */}
      <Card
        sx={{
          borderRadius: 2,
          boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
          overflow: 'hidden',
        }}
      >
        {/* Card Header */}
        <Box
          sx={{
            p: 3,
            borderBottom: '1px solid #f0f0f0',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: 2,
          }}
        >
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            {t('trainer_list')}
          </Typography>

          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap' }}>
            {/* Search */}
            <TextField
              placeholder={t('search_trainer') || 'Search...'}
              size="small"
              value={searchTermTrainer}
              onChange={(e) => setSearchTermTrainer(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon sx={{ color: '#999', fontSize: 20 }} />
                  </InputAdornment>
                ),
                endAdornment: searchTermTrainer && (
                  <InputAdornment position="end">
                    <IconButton size="small" onClick={handleClearSearch}>
                      <CloseIcon sx={{ fontSize: 18 }} />
                    </IconButton>
                  </InputAdornment>
                ),
              }}
              sx={{
                width: 250,
                '& .MuiOutlinedInput-root': {
                  bgcolor: '#fafafa',
                },
              }}
            />

            {/* Filters Button */}
            <Button
              variant="outlined"
              startIcon={<FilterListIcon />}
              onClick={openFilters.onTrue}
              sx={{
                textTransform: 'none',
                borderColor: '#ddd',
                color: '#666',
                '&:hover': {
                  borderColor: '#bbb',
                  bgcolor: '#f5f5f5',
                },
              }}
            >
              {t('Filters')}
            </Button>

            {/* Clear Filters */}
            {canReset && (
              <IconButton size="small" onClick={handleResetFilters}>
                <CloseIcon sx={{ fontSize: 18 }} />
              </IconButton>
            )}
          </Box>
        </Box>

        {/* Content Area */}
        <Box sx={{ p: 3 }}>
          {trainerListLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
              <CircularProgress />
            </Box>
          ) : trainerListError ? (
            <Typography color="error" textAlign="center" sx={{ py: 8 }}>
              {t('failed_to_load_trainers')}
            </Typography>
          ) : !trainers || trainers.length === 0 ? (
            <Box
              display="flex"
              flexDirection="column"
              alignItems="center"
              justifyContent="center"
              sx={{ py: 8, opacity: 0.75 }}
            >
              <HourglassEmptyIcon sx={{ fontSize: 48, color: 'text.disabled', mb: 2 }} />
              <Typography variant="h6" color="text.primary">
                {t('no_trainers_available')}
              </Typography>
            </Box>
          ) : (
            <Grid container spacing={3}>
              {trainers.map((trainer: any) => (
                <Grid item xs={12} sm={12} md={6} lg={6} key={trainer.id}>
                  <Box
                    sx={{
                      cursor: 'pointer',
                      '&:hover': {
                        transform: 'translateY(-2px)',
                        transition: 'transform 0.2s ease-in-out'
                      }
                    }}
                    onClick={() => handleClickTrainerDetails(trainer?.user_id)}
                  >
                    <TrainerProfileCard row={trainer} />
                  </Box>
                </Grid>
              ))}
            </Grid>
          )}
        </Box>

        {/* Pagination */}
        {trainers && trainers.length > 0 && (
          <Box
            sx={{
              borderTop: '1px solid #f0f0f0',
              px: 2,
              py: 1,
            }}
          >
            <TablePaginationCustom
              count={totalTrainerPages * table.rowsPerPage}
              page={table.page}
              rowsPerPage={table.rowsPerPage}
              onPageChange={table.onChangePage}
              onRowsPerPageChange={table.onChangeRowsPerPage}
            />
          </Box>
        )}
      </Card>

      {/* Filters Drawer */}
      <TrainerFilters
        open={openFilters.value}
        onOpen={openFilters.onTrue}
        onClose={openFilters.onFalse}
        filters={filters}
        onFilters={handleFilters}
        canReset={canReset}
        onResetFilters={handleResetFilters}
      />
    </Box>
  );
};

export default TrainerListPage;

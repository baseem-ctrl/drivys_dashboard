/* eslint-disable no-nested-ternary */
import React, { useState, useEffect } from 'react';
import {
  Avatar,
  Box,
  Card,
  Typography,
  Chip,
  Stack,
  TextField,
  InputAdornment,
  IconButton,
  CircularProgress,
  Button,
  Grid,
  Pagination,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import EmailIcon from '@mui/icons-material/Email';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import DirectionsBusIcon from '@mui/icons-material/DirectionsBus';
import SettingsIcon from '@mui/icons-material/Settings';
import { useTranslation } from 'react-i18next';

interface Trainer {
  id: number;
  user_id: number;
  name: string;
  email?: string;
  avatarUrl?: string;
  photo_url?: string;
  is_active?: boolean;
  user?: any;
}

interface TrainerStepProps {
  trainers: Trainer[];
  selectedTrainerId: number | null;
  setSelectedTrainerId: (id: number) => void;
  isLoading: boolean;
  setSearchTerm: (value: string) => void;
  searchTerm: string;
  renderFilters?: any;
  setSelectedTrainer: any;
}

const TrainerSelectStep: React.FC<TrainerStepProps> = ({
  trainers,
  selectedTrainerId,
  setSelectedTrainerId,
  isLoading,
  setSearchTerm,
  searchTerm,
  renderFilters,
  setSelectedTrainer,
}) => {
  const { i18n, t } = useTranslation();
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  // Reset to page 1 when trainers or search term changes
  useEffect(() => {
    setCurrentPage(1);
  }, [trainers.length, searchTerm]);

  const getInitials = (name?: string) => {
    if (!name) return t('n/a');
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase();
  };

  const handleClearSearch = () => {
    setSearchTerm('');
  };

  const getVehicleIcon = (categoryName: string) => {
    const lower = categoryName?.toLowerCase() || '';
    if (lower.includes('car')) return <DirectionsCarIcon sx={{ fontSize: 16 }} />;
    if (lower.includes('truck')) return <LocalShippingIcon sx={{ fontSize: 16 }} />;
    if (lower.includes('bus')) return <DirectionsBusIcon sx={{ fontSize: 16 }} />;
    return <DirectionsCarIcon sx={{ fontSize: 16 }} />;
  };

  const getVehicleColor = (categoryName: string) => {
    const lower = categoryName?.toLowerCase() || '';
    if (lower.includes('car')) return '#2196f3';
    if (lower.includes('truck')) return '#f44336';
    if (lower.includes('bus')) return '#4caf50';
    return '#2196f3';
  };

  // Calculate pagination
  const totalPages = Math.ceil(trainers.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentTrainers = trainers.slice(startIndex, endIndex);

  const handlePageChange = (event: React.ChangeEvent<unknown>, page: number) => {
    setCurrentPage(page);
    // Scroll to top when page changes
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <Box
        mb={3}
        sx={{ width: '100%' }}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        gap={2}
      >
        <TextField
          placeholder={t('search') || 'Search...'}
          variant="outlined"
          size="small"
          value={searchTerm}
          sx={{ maxWidth: '300px' }}
          onChange={(e) => setSearchTerm(e.target.value)}
          InputProps={{
            endAdornment: searchTerm && (
              <InputAdornment position="end">
                <IconButton size="small" onClick={handleClearSearch}>
                  <CloseIcon sx={{ fontSize: 18 }} />
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
      </Box>

      {isLoading ? (
        <Box sx={{ textAlign: 'center', py: 8 }}>
          <CircularProgress />
        </Box>
      ) : trainers.length === 0 ? (
        <Box sx={{ textAlign: 'center', py: 8, color: 'text.secondary' }}>
          <Typography>{t('no_trainers_found') || 'No trainers found'}</Typography>
        </Box>
      ) : (
        <>
          <Grid container spacing={3}>
            {currentTrainers.map((trainer) => {
              const trainerName =
                i18n.language === 'ar' ? trainer?.user?.name_ar : trainer?.user?.name;
              const trainerEmail = trainer?.user?.email;
              const photoUrl = trainer?.user?.photo_url || trainer.avatarUrl;
              const isActive = trainer?.user?.is_active;
              const gear = trainer?.user?.user_preference?.gear;
              const licenseNumber = trainer?.user?.license_number || trainer?.license_number;

              const vehicleCategory =
                trainer?.user?.user_preference?.vehicle_type?.category_translations?.find(
                  (trans: any) => trans?.locale?.toLowerCase() === i18n.language.toLowerCase()
                )?.name ||
                trainer?.user?.user_preference?.vehicle_type?.category_translations?.[0]?.name ||
                'N/A';

              const languages =
                trainer?.user?.languages?.length > 0
                  ? trainer?.user?.languages
                      .map((lang: any) => lang.dialect?.language_name)
                      .filter(Boolean)
                      .join(', ')
                  : 'N/A';

              return (
                <Grid item xs={12} md={6} key={trainer.user_id}>
                  <Card
                    sx={{
                      borderRadius: 3,
                      boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                      border: '1px solid #f0f0f0',
                      position: 'relative',
                      overflow: 'visible',
                      height: '100%',
                      '&:hover': {
                        boxShadow: '0 4px 12px rgba(0,0,0,0.12)',
                      },
                    }}
                  >
                    {/* Status Chip */}
                    <Chip
                      label={isActive ? t('active') : t('unavailable')}
                      size="small"
                      sx={{
                        position: 'absolute',
                        top: 16,
                        right: 16,
                        bgcolor: isActive ? '#4caf50' : '#f44336',
                        color: 'white',
                        fontWeight: 600,
                        fontSize: 11,
                        height: 24,
                        zIndex: 1,
                      }}
                    />

                    <Box sx={{ p: 2.5 }}>
                      {/* Avatar and Name */}
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                        <Avatar
                          src={photoUrl}
                          sx={{
                            width: 80,
                            height: 80,
                            borderRadius: 2,
                            bgcolor: '#f5f5f5',
                            fontSize: 24,
                            fontWeight: 600,
                            color: '#666',
                          }}
                        >
                          {getInitials(trainerName)}
                        </Avatar>
                        <Box sx={{ flex: 1 }}>
                          <Typography variant="h6" sx={{ fontWeight: 600, mb: 0.5, fontSize: 18 }}>
                            {trainerName || t('n/a')}
                          </Typography>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                            <EmailIcon sx={{ fontSize: 14, color: '#999' }} />
                            <Typography
                              variant="body2"
                              color="text.secondary"
                              sx={{ fontSize: 12 }}
                            >
                              {trainerEmail || t('n/a')}
                            </Typography>
                          </Box>
                        </Box>
                      </Box>

                      {/* Badges Row */}
                      <Stack direction="row" spacing={1} sx={{ mb: 2, flexWrap: 'wrap', gap: 1 }}>
                        {/* Manual Badge */}
                        {(gear === 'Manual' || gear === 1 || gear?.toLowerCase?.() === 'manual') && (
                          <Chip
                            icon={<SettingsIcon />}
                            label={t('manual') || 'Manual'}
                            size="small"
                            sx={{
                              bgcolor: '#2196f3',
                              color: 'white',
                              fontWeight: 600,
                              fontSize: 11,
                              height: 24,
                              '& .MuiChip-icon': { color: 'white', fontSize: 14 },
                            }}
                          />
                        )}

                        {/* Automatic Badge */}
                        {(gear === 'Automatic' ||
                          gear === 0 ||
                          gear?.toLowerCase?.() === 'automatic') && (
                          <Chip
                            icon={<SettingsIcon />}
                            label={t('automatic') || 'Automatic'}
                            size="small"
                            sx={{
                              bgcolor: '#ff9800',
                              color: 'white',
                              fontWeight: 600,
                              fontSize: 11,
                              height: 24,
                              '& .MuiChip-icon': { color: 'white', fontSize: 14 },
                            }}
                          />
                        )}

                        {/* License Number */}
                        {licenseNumber && (
                          <Chip
                            label={licenseNumber}
                            size="small"
                            variant="outlined"
                            sx={{
                              fontWeight: 600,
                              borderColor: '#ddd',
                              fontSize: 11,
                              height: 24,
                            }}
                          />
                        )}
                      </Stack>

                      {/* Vehicle Category */}
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
                        <Typography variant="body2" sx={{ fontSize: 12, color: '#666', minWidth: 100 }}>
                          {t('Vehicle Category') || 'Vehicle'}:
                        </Typography>
                        <Chip
                          icon={getVehicleIcon(vehicleCategory)}
                          label={vehicleCategory}
                          size="small"
                          sx={{
                            bgcolor: getVehicleColor(vehicleCategory),
                            color: 'white',
                            fontWeight: 600,
                            fontSize: 11,
                            height: 24,
                            '& .MuiChip-icon': { color: 'white', fontSize: 14 },
                          }}
                        />
                      </Box>

                      {/* Languages */}
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                        <Typography variant="body2" sx={{ fontSize: 12, color: '#666', minWidth: 100 }}>
                          {t('language') || 'Language'}:
                        </Typography>
                        <Typography variant="body2" sx={{ fontSize: 12, color: '#333' }}>
                          {languages}
                        </Typography>
                      </Box>

                      {/* Select Button */}
                      <Button
                        fullWidth
                        variant={trainer.user_id === selectedTrainerId ? 'contained' : 'outlined'}
                        onClick={() => {
                          setSelectedTrainerId(trainer.user_id);
                          setSelectedTrainer(trainer);
                        }}
                        sx={{
                          textTransform: 'none',
                          borderRadius: 2,
                          py: 1,
                          fontWeight: 600,
                          ...(trainer.user_id === selectedTrainerId
                            ? {
                                bgcolor: '#ff6b35',
                                '&:hover': { bgcolor: '#ff5722' },
                              }
                            : {
                                borderColor: '#ff6b35',
                                color: '#ff6b35',
                                '&:hover': {
                                  borderColor: '#ff6b35',
                                  bgcolor: 'rgba(255,107,53,0.04)',
                                },
                              }),
                        }}
                      >
                        {trainer.user_id === selectedTrainerId
                          ? t('selected') || 'Selected'
                          : t('select_trainer') || 'Select Trainer'}
                      </Button>
                    </Box>
                  </Card>
                </Grid>
              );
            })}
          </Grid>

          {/* Pagination */}
          {totalPages > 1 && (
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
              <Pagination
                count={totalPages}
                page={currentPage}
                onChange={handlePageChange}
                color="primary"
                size="large"
                showFirstButton
                showLastButton
                sx={{
                  '& .MuiPaginationItem-root': {
                    fontWeight: 600,
                  },
                  '& .Mui-selected': {
                    bgcolor: '#ff6b35 !important',
                    color: 'white',
                    '&:hover': {
                      bgcolor: '#ff5722 !important',
                    },
                  },
                }}
              />
            </Box>
          )}
        </>
      )}
    </>
  );
};

export default TrainerSelectStep;

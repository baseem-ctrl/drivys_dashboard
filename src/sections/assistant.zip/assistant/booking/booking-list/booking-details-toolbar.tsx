// @mui
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
// routes
import { RouterLink } from 'src/routes/components';
// utils
import { fDateTime } from 'src/utils/format-time';
// components
import Label from 'src/components/label';
import Iconify from 'src/components/iconify';
import CustomPopover, { usePopover } from 'src/components/custom-popover';
import { useTranslation } from 'react-i18next';

// ----------------------------------------------------------------------

type Props = {
  status: number;
  backLink: string;
  orderNumber: string;
  createdAt: Date;
  onChangeStatus: (newValue: number) => void;
  statusOptions: {
    value: string;
    label: string;
  }[];
  statusId: any;
};

export default function BookingDetailsToolbar({
  status,
  statusId,
  backLink,
  createdAt,
  orderNumber,
  statusOptions,
  onChangeStatus,
}: Props) {
  const popover = usePopover();

  const { t, i18n } = useTranslation();

  return (
    <>
      <Stack
        spacing={3}
        direction={{ xs: 'column', md: 'row' }}
        sx={{
          mb: { xs: 3, md: 5 },
        }}
      >
        <Stack spacing={1} direction="row" alignItems="flex-start">
          <IconButton component={RouterLink} href={backLink}>
            {i18n.language === 'en' ? <Iconify icon="eva:arrow-ios-back-fill" /> : <Iconify icon="eva:arrow-ios-back-fill" sx={{ transform: 'rotate(180deg)' }} />}
          </IconButton>

          <Stack spacing={0.5}>
            <Stack spacing={1} direction="row" alignItems="center">
              <Typography variant="h4">
                {' '}
                {t('Order')} {orderNumber}{' '}
              </Typography>

              <Label
                variant="soft"
                color={
                  (status === 'PENDING' && 'info') ||
                  (status === 'IN PROGRESS' && 'warning') ||
                  (status === 'CANCELLED' && 'error') ||
                  (status === 'CONFIRMED' && 'secondary') ||
                  'success'
                }
              >
                {status}
              </Label>
            </Stack>

            <Typography variant="body2" sx={{ color: 'text.disabled' }}>
              {fDateTime(createdAt)}
            </Typography>
          </Stack>
        </Stack>

        <Stack
          flexGrow={1}
          spacing={1.5}
          direction="row"
          alignItems="center"
          justifyContent="flex-end"
        >
          <Button
            color="inherit"
            variant="outlined"
            endIcon={<Iconify icon="eva:arrow-ios-downward-fill" />}
            onClick={popover.onOpen}
            sx={{ textTransform: 'capitalize' }}
          >
            {status}
          </Button>

          {/* <Button color="inherit" variant="contained" startIcon={<Iconify icon="solar:pen-bold" />}>
            Edit
          </Button> */}
        </Stack>
      </Stack>

      <CustomPopover
        open={popover.open}
        onClose={popover.onClose}
        arrow="top-right"
        sx={{ width: 140 }}
      >
        {statusOptions.map((option) => (
          <MenuItem
            key={option.value}
            selected={parseInt(option.value, 10) === statusId}
            onClick={() => {
              popover.onClose();
              onChangeStatus(parseInt(option.value, 10));
            }}
          >
            {option.name}
          </MenuItem>
        ))}
      </CustomPopover>
    </>
  );
}
